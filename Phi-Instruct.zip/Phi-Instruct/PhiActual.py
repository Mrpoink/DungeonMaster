from transformers import AutoTokenizer, AutoModelForCausalLM, Trainer, TrainingArguments, BitsAndBytesConfig, DataCollatorForLanguageModeling
from datasets import load_dataset, Dataset
import warnings
from peft import get_peft_model, LoraConfig, prepare_model_for_kbit_training, PeftModel
import torch
import asyncio
import json
import evaluate
import random
import numpy as np
import sys
import os
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

sys.path.append(project_root)

import vector_database

metric = evaluate.load('accuracy')

warnings.filterwarnings("ignore", category=UserWarning, module="peft.peft_model")


def section_string(initial : str, beginning : str, ending : str):
    first_section = initial.split(beginning)
    final = first_section[1].split(ending)

    return final[0]

def remove_parts(initial : str):
    sections = initial.split("[")
    if "|" in sections[0]:
        sections = sections[0].split("|")
    final = sections[0]

    return final


bnb_config = BitsAndBytesConfig(
    load_in_8bit=True,
    bnb_8bit_quant_type="nf8",
    bnb_8bit_compute_dtype=torch.bfloat16
)

lora_config = LoraConfig(
    r=8,
    lora_alpha=16,
    target_modules=["q_proj", "v_proj"],
    lora_dropout=0.05,
    bias="none",
    task_type="CAUSAL_LM"
)


tokenizer = AutoTokenizer.from_pretrained("microsoft/Phi-3-mini-4k-instruct")
base_model = AutoModelForCausalLM.from_pretrained(
    "microsoft/Phi-3-mini-4k-instruct",
    dtype = torch.bfloat16,
    device_map = "cpu"
    )
model = PeftModel.from_pretrained(base_model, "prompt_classifier_phi/checkpoint-4452", low_cpu_mem_usage=True, quantization_config = bnb_config)

model.eval()


async def main():

    turn_num = 0

    top_p = .65
    top_k = 40
    repetition_penalty = 5.0
    temperature = 0.85

    userin = ""

    prompt = "[/SCENE]: The streets of the well known city of Zanzerick"

    vb = vector_database.get_from_db()

    await vb.connect()

    seed = random.randint(20, 65)

    await vb.add_session('all-MiniLM-L6-v2', prompt, seed)

    while (userin != "q"):

        torch.cuda.empty_cache()

        userin = input("Enter Prompt: ")

        prompt = f"{prompt} [/ACTION]: {userin}|end|\n|assistant|: [/OUTCOME]: "

        similarities = await vb.best_result(0.0,'all-MiniLM-L6-v2', prompt, seed)

        extra_info = ""

        initial_confidence = 0.0

        for item in similarities:

            name, entry, confidence = item

            text = entry['text']

            userin_list = userin.split(' ')

            text_split = text.split(' ')

            is_in = False

            for item in userin_list:

                if item not in text_split:

                    continue

                else:
                    is_in = True

            if is_in == False:

                continue

            if confidence > initial_confidence and (name != "SESSION"):
                print(name)
                initial_confidence = confidence

                extra_info = f"{extra_info} {entry['text']},"

            elif ((confidence > initial_confidence) and (name == "SESSION")) or (turn_num != 0):
                print(name)
                initial_confidence = confidence

                extra_info = f"[/EXTRA INFO]: {entry['text']},"

        prompt = f"|user|: {extra_info} {prompt}"



        inputs = tokenizer(prompt, return_tensors="pt").to("cpu")

        with torch.no_grad():
            ouputs = model.generate(
                **inputs, 
                max_new_tokens = 256,
                num_beams=2,
                num_return_sequences=1,
                return_dict_in_generate=True,
                output_scores=True,
                do_sample=True,
                top_p = top_p,
                top_k = top_k,
                pad_token_id=tokenizer.eos_token_id,
                eos_token_id=tokenizer.eos_token_id,
                repetition_penalty = repetition_penalty,
                temperature = temperature
            )

        print(len(ouputs))

        decoded_ouput = tokenizer.decode(ouputs[0][0], skip_special_tokens = True)

        final_output = section_string(decoded_ouput, "[/OUTCOME]:", "\n")

        if "[" in final_output:
            final_output = remove_parts(final_output)

        if "[/RESULTS]:" in final_output:
            final_output = section_string(final_output, "[/RESULTS]: ", "\n")

        print(f"Model Output: {decoded_ouput}")
        print(f"\n\nFINAL OUTPUT: {final_output}")

        prompt = ""
        turn_num +=1

        user_choice = input("Is this output good?(y/n): ")

        if user_choice =='y':
            await vb.add_session('all-MiniLM-L6-v2', str(final_output), seed)
        else:
            sys.exit(0)


asyncio.run(main())