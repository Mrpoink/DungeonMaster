from transformers import AutoTokenizer, AutoModelForCausalLM, Trainer, TrainingArguments, BitsAndBytesConfig, DataCollatorForLanguageModeling
from datasets import load_dataset, Dataset
import warnings
from peft import get_peft_model, LoraConfig, prepare_model_for_kbit_training, PeftModel
import torch
import asyncio
import json
import evaluate
import random
import numpy as np
import sys
import os
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

sys.path.append(project_root)

import vector_database

metric = evaluate.load('accuracy')

warnings.filterwarnings("ignore", category=UserWarning, module="peft.peft_model")


def section_string(initial : str, beginning : str, ending : str):
    first_section = initial.split(beginning)
    final = first_section[1].split(ending)

    return final[0]


bnb_config = BitsAndBytesConfig(
    load_in_8bit=True,
    bnb_8bit_quant_type="nf8",
    bnb_8bit_compute_dtype=torch.bfloat16
)

lora_config = LoraConfig(
    r=8,
    lora_alpha=16,
    target_modules=["q_proj", "v_proj"],
    lora_dropout=0.05,
    bias="none",
    task_type="CAUSAL_LM"
)


tokenizer = AutoTokenizer.from_pretrained("microsoft/Phi-3-mini-4k-instruct")
base_model = AutoModelForCausalLM.from_pretrained(
    "microsoft/Phi-3-mini-4k-instruct",
    dtype = torch.bfloat16,
    device_map = "auto"
    )
model = PeftModel.from_pretrained(base_model, "prompt_classifier_phi/checkpoint-4452", ephemeral_gpu_offload=True, low_cpu_mem_usage=True, quantization_config = bnb_config)

model.eval()


async def main():

    top_p = 1.05
    top_k = 35
    repetition_penalty = 5.5
    temperature = .75

    userin = ""

    prompt = "[/SCENE]: The party has entered the Dungeon of Flairs. [/ACTION]: I look into the room on the right|end|\n|assistant|: [/OUTCOME]:"

    vb = vector_database.get_from_db()

    await vb.connect()

    seed = random.randint(20, 65)

    await vb.add_session('all-MiniLM-L6-v2', prompt, seed)

    while (userin != "q"):

        torch.cuda.empty_cache()

        print(f"Prompt: {prompt}")

        userin = input("Would you like to change anything?(y/n): ")

        if userin == "y":

            while (userin != "next"):


                print(f"Current values:\n")
                print(f"\ntop_p: {top_p}, top_k: {top_k}, rep_pen: {repetition_penalty}, temp: {temperature}\n")
                print(f"\n\tp:Select the smallest set of tokens whose cumulative probability is greater than p\n \
                    k:Only consider the k most probable tokens for sampling. If your model is stuck, try a lower value (e.g., 30 or 20) to focus the model, or a higher value (e.g., 100) to increase the pool of choices.\n \
                    rep: Repetition penalty\n \
                    temp: temperature")
                userin = input(f"Change any of them? (p, k, rep, temp, prompt) or 'next' to continue to generation: ")
                

                match userin:
                    case "p":
                        top_p = float(input("Enter value (float): "))
                    case "k":
                        top_k = int(input("Enter value (int): "))
                    case "rep":
                        repetition_penalty = float(input("Enter value (float): "))
                    case "temp":
                        temperature = float(input("Enter value (float): "))
                    case "prompt":
                        prompt = input("Enter new prompt: ")
                    case "next":
                        break

        similarities = await vb.best_result(0.0,'all-MiniLM-L6-v2', prompt, seed)

        extra_info = ""

        initial_confidence = 0.0

        for item in similarities:

            name, entry, confidence = item

            text = entry['text']

            userin_list = userin.split(' ')

            text_split = text.split(' ')

            is_in = False

            for item in userin_list:

                if item not in text_split:

                    continue

                else:
                    is_in = True

            if is_in == False:

                continue

            if confidence > initial_confidence and (name != "SESSION"):
                print(name)
                initial_confidence = confidence

                extra_info = f"[/EXTRA INFO]: {entry['text']},"

            else:
                print(name)

        prompt = f"|user|: {extra_info} {prompt}"



        inputs = tokenizer(prompt, return_tensors="pt").to("cuda")

        with torch.no_grad():
            ouputs = model.generate(
                **inputs, 
                max_new_tokens = 256,
                num_beams=2,
                num_return_sequences=1,
                return_dict_in_generate=True,
                output_scores=True,
                do_sample=True,
                top_p = top_p, #WAS 0.5
                top_k = top_k,
                pad_token_id=tokenizer.eos_token_id,
                eos_token_id=tokenizer.eos_token_id,
                repetition_penalty = repetition_penalty,
                temperature = temperature
            )

        print(len(ouputs))

        decoded_ouput = tokenizer.decode(ouputs[0][0], skip_special_tokens = True)

        final_output = section_string(decoded_ouput, "[/OUTCOME]:", "\n")

        print(f"Model Output: {decoded_ouput}")
        print(f"\n\nFINAL OUTPUT: {final_output}")


asyncio.run(main())