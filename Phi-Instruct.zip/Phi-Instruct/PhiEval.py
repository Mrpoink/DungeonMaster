from transformers import AutoTokenizer, AutoModelForCausalLM, Trainer, TrainingArguments, BitsAndBytesConfig, DataCollatorForLanguageModeling
from datasets import load_dataset, Dataset
import warnings
from peft import get_peft_model, LoraConfig, prepare_model_for_kbit_training, PeftModel
import torch
import json
import evaluate
import numpy as np

metric = evaluate.load('accuracy')

warnings.filterwarnings("ignore", category=UserWarning, module="peft.peft_model")

bnb_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_compute_dtype=torch.bfloat16
)

lora_config = LoraConfig(
    r=8,
    lora_alpha=16,
    target_modules=["q_proj", "v_proj"],
    lora_dropout=0.05,
    bias="none",
    task_type="CAUSAL_LM"
)


tokenizer = AutoTokenizer.from_pretrained("microsoft/Phi-3-mini-4k-instruct")
base_model = AutoModelForCausalLM.from_pretrained(
    "microsoft/Phi-3-mini-4k-instruct",
    dtype = torch.bfloat16,
    device_map = "auto"
    )
model = PeftModel.from_pretrained(base_model, "prompt_classifier_phi/checkpoint-28492")

model.eval()


prompt = "|user|: [/SCENE]: The party has entered the Dungeon of Flairs. [/ACTION]: I look into the room on the right|end|\n|assistant|:"



inputs = tokenizer(prompt, return_tensors="pt").to("cuda")

with torch.no_grad():
    ouputs = model.generate(
        **inputs, 
        max_new_tokens = 256,
        num_beams=2,
        num_return_sequences=1,
        return_dict_in_generate=True,
        output_scores=True,
        do_sample=True,
        top_p = 1.8, #WAS 0.5
        top_k = 45,
        pad_token_id=tokenizer.eos_token_id,
        eos_token_id=tokenizer.eos_token_id,
        repetition_penalty = 1.7,
        temperature = 0.98
    )

print(len(ouputs))

decoded_ouput = tokenizer.decode(ouputs[0][0], skip_special_tokens = True)

print(f"Model Output: {decoded_ouput}")
