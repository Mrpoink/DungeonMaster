from transformers import AutoTokenizer, AutoModelForCausalLM, Trainer, TrainingArguments, BitsAndBytesConfig, DataCollatorForLanguageModeling
from datasets import load_dataset, Dataset
from peft import get_peft_model, LoraConfig, prepare_model_for_kbit_training, PeftModel
import torch
import json
import evaluate
import numpy as np
import sys
import os
import asyncio
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

sys.path.append(project_root)

from Datasets import vector_database



torch.cuda.empty_cache()
metric = evaluate.load('accuracy')


bnb_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_compute_dtype=torch.bfloat16,
    llm_int8_enable_fp32_cpu_offload=True
)

lora_config = LoraConfig(
    r=8,
    lora_alpha=16,
    target_modules=["q_proj", "v_proj"],
    lora_dropout=0.05,
    bias="none",
    task_type="CAUSAL_LM"
)


tokenizer = AutoTokenizer.from_pretrained("mistralai/Mistral-7B-Instruct-v0.3")
base_model = AutoModelForCausalLM.from_pretrained(
    "mistralai/Mistral-7B-Instruct-v0.3",
    quantization_config = bnb_config,
    dtype = torch.bfloat16
    )
model = PeftModel.from_pretrained(base_model, "/home/mrpoink/github-repos/DungeonMaster/DungeonMaster/prompt_classifier_mistral/checkpoint-4600")

model.eval()

async def main():


    prompt = "input: [SCENE]: City of Hope Tavern. [ACTION] I ask the barkeep what a human paladin is. output:\n"

    vb = vector_database.get_from_db()

    await vb.connect()

    prompt_split = prompt.split(" ")

    similarities = await vb.db_get('all-MiniLM-L6-v2', prompt_split)

    extra_info = ""

    for item in similarities:

        extra_info = f"{extra_info}, {item},"

    prompt = f"{prompt} EXTRA INFO: {extra_info}\noutput:"

    inputs = tokenizer(prompt, return_tensors="pt").to("cuda")

    with torch.no_grad():
        ouputs = base_model.generate(
            **inputs,
            max_new_tokens = 128
        )

    decoded_ouput = tokenizer.decode(ouputs[0], skip_special_tokens = True)

    decoded_ouput = decoded_ouput.split("output: ")

    print(decoded_ouput[1])


asyncio.run(main())
