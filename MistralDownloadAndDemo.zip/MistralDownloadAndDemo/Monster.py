from jsonPuller import get_data as data

class Monster:

    def __init__(self, data):
        #Should place data into variables, will be determined by return of data
        pass

    #Needs to have return statements for the different things